<?php

header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: content-type, authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
