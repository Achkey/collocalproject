<?php 

namespace App\Interfaces;

interface UserInterface
{
    public function getUsername(): string;
}

?>