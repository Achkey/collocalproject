//const base_url = "https://sarallagani.com/api";
const base_url = "http://localhost:1414";
export const api_baseUrl = base_url;