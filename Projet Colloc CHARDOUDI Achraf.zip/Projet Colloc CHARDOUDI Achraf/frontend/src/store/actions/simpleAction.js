import { connect } from "react-redux";
import { SET_USER_INFO } from "../type"

export const storeUserInfo = (data) => {
  return({
    type: SET_USER_INFO,
    data
  })
}


