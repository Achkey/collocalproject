export const SET_USER_INFO = "SET_USER_INFO";
export const SET_FLAT_ID = "SET_FLAT_ID";
export const SET_FLAT_INFO = "SET_FLAT_INFO";