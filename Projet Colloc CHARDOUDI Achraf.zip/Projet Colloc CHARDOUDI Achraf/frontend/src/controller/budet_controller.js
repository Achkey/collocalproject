export async function divideBudget(totalBudget, numColloc) { 
    let dividedPrice = totalBudget / numColloc;
    return dividedPrice;
}